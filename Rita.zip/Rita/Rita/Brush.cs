﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Rita
{
    class Brush
    {
        public int x, y, brushSize;

		public Color color;

        public Brush(int x, int y, Color color, int brushSize) {
            this.x = x;
            this.y = y;
            this.brushSize = brushSize;
			this.color = color;
        }

        public void Draw(Graphics g) {

            g.FillEllipse(new SolidBrush(color), x, y, brushSize, brushSize);
        }


    }
}
