﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Rita
{
    class Färg
    {
        int x, y, r,b,g;

        Rectangle rect;

        Color color;

        public Färg(int x, int y, int r, int g, int b) {
            this.x = x;
            this.y = y;
            this.r = r;
            this.g = g;
            this.b = b;

            rect = new Rectangle(x,y,20,20);
            Color color = Color.FromArgb(1, r, g, b);
        }

        public Color choosen() {
                      
            return color;
           
        }

        public void Rita(Graphics g){
            g.FillRectangle(new SolidBrush(color), rect);
        }

    }
}
