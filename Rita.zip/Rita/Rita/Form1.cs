﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rita
{
    public partial class Form1 : Form
    {
        Queue<Ansikte> ansikten = new Queue<Ansikte>();

        bool isMouseDown = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            //ansikten.Enqueue(new Ansikte(e.X, e.Y));
            //Invalidate();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (ansikten.Count > 0)
            {
                ansikten.Dequeue();
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            foreach (Ansikte ansikte in ansikten)
            {
                ansikte.Rita(e.Graphics);
            }

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            isMouseDown = true;
 
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown) {
                ansikten.Enqueue(new Ansikte(e.X, e.Y));
                Invalidate();    
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            isMouseDown = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ansikten.Clear();
            Invalidate();
        }

    }
}
