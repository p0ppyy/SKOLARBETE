﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rita
{
    public partial class Form1 : Form
    {
        //Lägg till en button klass istället för de andra klasserna och använd colordialog för att välja färg.

        Queue<Brush> strokes = new Queue<Brush>();

		Stack<List<Brush>> strokesA = new Stack<List<Brush>>();

		List<Brush> temp = new List<Brush>();

		bool isMouseDown = false;

		Rectangle mouseRect = new Rectangle();

		Color selectedColor = new Color();

		Random rand = new Random();

        Button colorButton;

        Button eraserButton;

        int brushSize = 0;

        

        public Form1()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, EventArgs e)
		{
			mouseRect.Width = 2;
			mouseRect.Height = 2;

            selectedColor = Color.Black;
            brushSize = brushSizeBar.Value;

            colorButton = new Button(10, 10, 50, 50, selectedColor);
            eraserButton = new Button(70, 10, 50, 50, Properties.Resources.eraser_512);

            lblBrushSize.Text = "Brushsize: " + brushSize;

          
		}

		private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if(mouseRect.IntersectsWith(colorButton.Bounds)){
                colorButton.Clicked = true;
            }else if(mouseRect.IntersectsWith(eraserButton.Bounds)){
                selectedColor = Color.FromName("Control");        
            }

            if (colorButton.Clicked) {
                colorDialog1.ShowDialog();
                selectedColor = colorDialog1.Color;
                colorButton.changeColor(selectedColor);
            }

            if (!mouseRect.IntersectsWith(colorButton.Bounds)) {
                temp.Add(new Brush(e.X, e.Y, selectedColor, brushSize));
            }
			
	        colorButton.Clicked = false;

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (strokesA.Count > 0)
            {
				strokesA.Pop();
				Invalidate();
            }

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);



			for (int i = strokesA.Count - 1; i >= 0; i--)
			{
				for (int j = 0; j < strokesA.ElementAt(i).Count; j++)
				{
					strokesA.ElementAt(i)[j].Draw(e.Graphics);
				}
			}


			foreach (Brush brush in temp)
			{
				brush.Draw(e.Graphics);
            }

            colorButton.Draw(e.Graphics);
            eraserButton.Draw(e.Graphics);
		}

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            isMouseDown = true;
                   
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
			mouseRect.X = e.X;
			mouseRect.Y = e.Y;
			Invalidate();

			if (isMouseDown){
				if(e.Y > 50)
				temp.Add(new Brush(e.X, e.Y, selectedColor, brushSize));
			}
			else if (!isMouseDown && temp.Count > 0) {
				strokesA.Push(new List<Brush>(temp));
				temp.Clear();
			}
		}

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            isMouseDown = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            strokesA.Clear();
			Invalidate();
		}

        private void brushSizeBar_Scroll(object sender, EventArgs e)
        {
            
            brushSize = brushSizeBar.Value;
            lblBrushSize.Text = "Brushsize: " + brushSize;

        }
        


    }
}
