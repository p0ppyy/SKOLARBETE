﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rita
{
    public partial class Form1 : Form
    {
        //Lägg till enn button klass istället för de andra klasserna och använd colordialog för att välja färg.


        Queue<Brush> strokes = new Queue<Brush>();

		Stack<List<Brush>> strokesA = new Stack<List<Brush>>();

		List<Brush> temp = new List<Brush>();

		bool isMouseDown = false;

		Färg[] färger = new Färg[20];
        Size[] sizes = new Size[20];

		Rectangle mouseRect = new Rectangle();

		Color selectedColor = new Color();

		Random rand = new Random();

        int brushSize = 0;

        

        public Form1()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, EventArgs e)
		{
			mouseRect.Width = 2;
			mouseRect.Height = 2;

			for (int i = 0; i < färger.Length; i++)
			{
				if (i == 0)

					färger[i] = new Färg(i * Width / färger.Length, 0, Color.FromName("Control"), Width / färger.Length);
				else
					färger[i] = new Färg(i * Width / färger.Length, 0, Color.FromArgb(rand.Next(255), rand.Next(255), rand.Next(255)), Width / färger.Length);
			}

            for (int i = 0; i < sizes.Length; i++)
            {
                sizes[i] = new Size((i + 2) * 2, i * Width / sizes.Length, 50, Width / sizes.Length);
            }

            

		}

		private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
			if(e.Y > 50)
				temp.Add(new Brush(e.X, e.Y, selectedColor, brushSize));

            if (e.Y > 100 && e.Y < 200) {
                ColorDialog cdl = new ColorDialog();
                cdl.ShowDialog();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (strokesA.Count > 0)
            {
				strokesA.Pop();
				Invalidate();
            }

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

			foreach (Färg färg in färger)
			{
				färg.Draw(e.Graphics);
			}



			for (int i = strokesA.Count - 1; i >= 0; i--)
			{
				for (int j = 0; j < strokesA.ElementAt(i).Count; j++)
				{
					strokesA.ElementAt(i)[j].Draw(e.Graphics);
				}
			}


			foreach (Brush brush in temp)
			{
				brush.Draw(e.Graphics);
			}
            foreach (Size size in sizes)
            {
                size.Draw(e.Graphics);
            }

		}

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            isMouseDown = true;

            if (e.Y < 50)
            {
                foreach (Färg färg in färger)
                {
                    färg.DeSelect();

                    if (mouseRect.IntersectsWith(färg.getRect()))
                    {
                        selectedColor = färg.Select();
                    }
                }
            }
            if (e.Y > 50 && e.Y < 100) {
                foreach (Size size in sizes) {
                    size.DeSelect();

                    if (mouseRect.IntersectsWith(size.getRect())) {

                        brushSize = size.Select();
                    }
                }
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
			mouseRect.X = e.X;
			mouseRect.Y = e.Y;
			Invalidate();

			if (isMouseDown){
				if(e.Y > 50)
				temp.Add(new Brush(e.X, e.Y, selectedColor, brushSize));
			}
			else if (!isMouseDown && temp.Count > 0) {
				strokesA.Push(new List<Brush>(temp));
				temp.Clear();
			}
		}

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            isMouseDown = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            strokesA.Clear();
			Invalidate();
		}

    }
}
